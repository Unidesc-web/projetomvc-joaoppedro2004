﻿using Microsoft.AspNetCore.Mvc;

namespace SeuProjeto.Controllers
{
    public class ClientesController : Controller
    {
        // Simulação de uma lista de clientes
        public IActionResult Index()
        {
            var clientes = new List<string>
            {
                "João Silva",
                "Maria Oliveira",
                "Carlos Souza"
            };

            // Passando a lista de clientes para a View
            return View(clientes);
        }
    }
}
