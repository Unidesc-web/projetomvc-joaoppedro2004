﻿using Microsoft.AspNetCore.Mvc;

namespace SeuProjeto.Controllers
{
    public class CarrosController : Controller
    {
        // Simulação de uma lista de carros
        public IActionResult Index()
        {
            var carros = new List<string>
            {
                "Fusca 1984",
                "Civic 2020",
                "BMW X1"
            };

            // Passando a lista de carros para a View
            return View(carros);
        }
    }
}
