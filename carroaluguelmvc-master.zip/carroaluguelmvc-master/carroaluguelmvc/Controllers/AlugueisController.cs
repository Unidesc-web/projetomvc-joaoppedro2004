﻿using Microsoft.AspNetCore.Mvc;

namespace SeuProjeto.Controllers
{
    public class AlugueisController : Controller
    {
        // Simulação de uma lista de aluguéis
        public IActionResult Index()
        {
            var alugueis = new List<string>
            {
                "João Silva alugou o Fusca 1984",
                "Maria Oliveira alugou o Civic 2020",
                "Carlos Souza alugou o BMW X1"
            };

            // Passando a lista de aluguéis para a View
            return View(alugueis);
        }
    }
}
