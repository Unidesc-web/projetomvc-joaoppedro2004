﻿using System;

namespace SeuProjeto.Models
{
    public class Aluguel
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public int CarroId { get; set; }
        public DateTime DataRetirada { get; set; }
        public DateTime DataDevolucao { get; set; }
    }
}
