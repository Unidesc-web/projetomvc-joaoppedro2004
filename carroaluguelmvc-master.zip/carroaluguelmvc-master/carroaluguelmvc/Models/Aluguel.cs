﻿namespace AluguelDeCarrosMVC.Models
{
    public class Aluguel
    {
        public int Id { get; set; }
        public string Cliente { get; set; }
        public string Carro { get; set; }
        public DateTime Data { get; set; }
    }
}
